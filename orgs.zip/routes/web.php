<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('index');
});
Route::view('/administrative-structure.blade', 'administrative-structure.blade');
Route::view('/adminregulations.blade', 'adminregulations.blade');
Route::view('/annual-budget.blade', 'annual-budget.blade');
Route::view('/annual-reports.blade', 'annual-reports.blade');
Route::view('/association-offices.blade', 'association-offices.blade');
Route::view('/associations-leaders.blade', 'associations-leaders.blade');
Route::view('/bank-info.blade', 'bank-info.blade');
Route::view('/begining.blade', 'begining.blade');
Route::view('/block.blade', 'block.blade');
Route::view('/board-of-directors.blade', 'board-of-directors.blade');
Route::view('/email.blade', 'email.blade');
Route::view('/feasibility-policy.blade', 'feasibility-policy.blade');
Route::view('/fieldregulations.blade', 'fieldregulations.blade');
Route::view('/hoffadh.blade', 'hoffadh.blade');
// Route::view('/index.blade', 'index.blade');
Route::view('/initiative.blade', 'initiative.blade');
Route::view('/measu-benefi.blade', 'measu-benefi.blade');
Route::view('/meet.blade', 'meet.blade');
Route::view('/member-general.blade', 'member-general.blade');
Route::view('/news.blade', 'news.blade');
Route::view('/objectif.blade', 'objectif.blade');
Route::view('/operational-plans.blade', 'operational-plans.blade');
Route::view('/policies.blade', 'policies.blade');
Route::view('/recruitment.blade', 'recruitment.blade');
Route::view('/setup-loop.blade', 'setup-loop.blade');
Route::view('/standing-committees.blade', 'standing-committees.blade');
Route::view('/statistics.blade', 'statistics.blade');
Route::view('/test.blade', 'test.blade');
Route::view('/training.blade', 'training.blade');
Route::view('/vision-message.blade', 'vision-message.blade');