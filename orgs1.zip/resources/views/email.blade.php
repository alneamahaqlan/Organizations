<!DOCTYPE html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>نمو</title>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
        <!-- jQuery Library -->

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

        <!-- Counts JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.rtl.min.css"
      integrity="sha384-gXt9imSW0VcJVHezoNQsP+TNrjYXoGcrqBZJpry9zJt8PCQjobwmhMGaDHTASo9N"
      crossorigin="anonymous"
    />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic&family=Poppins:wght@400;500&display=swap"
      rel="stylesheet"
    />
    
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <header>
      <section id="top-sc-em">
        <div class="container-fluid">
          <div class="top-nav d-flex justify-content-end">
            <div class="call-us d-flex">
              <i class="fa-solid fa-phone-flip mhc-menu-icon"></i>
              <a href="#"> اتصل بنا </a>
            </div>
            <div class="problem-rep d-flex">
              <i class="fa-regular fa-thumbs-up mhc-menu-icon"></i>
              <a href="#"> الاقتراحات والشكاوى </a>
            </div>
          </div>
        </div>
      </section>

      <section id="navbar">
        <div class="mt-2 al-nav container-fluid">
          <div class="logo col-lg-1   ">
            <a class="navbar-brand logo-nav" href="index.html"
              ><img src="./images/logo.png" alt=""
            /></a>
          </div>
          <div class="navbar-con col-lg-9 ">
            <nav class="navbar navbar-expand-lg navbar-light">
              <div class="container-fluid">
                <button
                  class="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div
                  class="collapse navbar-collapse justify-content-evenly"
                  id="navbarSupportedContent"
                >
                  <ul class="navbar-nav mb-2 mb-lg-0">
                    <li class="nav-item">
                      <a class="nav-link active" aria-current="page" 
                      href="index.html"
                        >الرئيسية</a
                      >
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        نمو
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          
                          <a class="dropdown-item" href="objectif.html">
                            <i class="fa-solid fa-bullseye"></i>
                          أهداف الجمعية
                            
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="begining.html">
                            <i class="fa-solid fa-flag-checkered"></i>
                            النشأة والبداية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#"> 
                            <i class="fa-solid fa-user-tie"></i>
                            المؤسس 
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="board-of-directors.html">
                            <i class="fa-solid fa-users-line"></i>
                            أعضاء مجلس الإدارة
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="administrative-structure.html">
                            <i class="fa-solid fa-users-gear"></i>
                             الهيكل الإداري </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="operational-plans.html">
                            <i class="fa-solid fa-newspaper"></i>
                             خطط جمعية نمو </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="measu-benefi.html">
                            <i class="fa-solid fa-chart-line"></i>
                            قياس رضا المستفيدين
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="feasibility-policy.html">
                            <i class="fa-solid fa-check"></i>
                             سياسة الجودة </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="vision-message.html">
                            <i class="fa-solid fa-eye"></i>
                            الرؤية والرسالة
                          </a>
                        </li>
                        <!-- <li><hr class="dropdown-divider" /></li>
                        <li>
                          <a class="dropdown-item" href="#"
                            >Something else here</a
                          >
                        </li> -->
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        الخدمات
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-file-lines"></i>

                            نظام نمو
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="setup-loop.html">
                            <i class="fa-solid fa-user-plus"></i>
                            طلب إقامة برنامج
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="initiative.html">
                            <i class="fa-solid fa-handshake-angle"></i>
                            المبادرات
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="email.html">
                            <i class="fa-regular fa-envelope"></i>
                            البريد الإلكتروني
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="training.html">
                            <i class="fa-solid fa-gears"></i>
                            نظام إدارة التدريب لمنسوبي الجمعية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="hoffadh.html">
                            <i class="fa-solid fa-mobile-screen-button"></i>
                            منصة نمو التعليمية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="https://maps.app.goo.gl/mnxYorDidK3eU1L77">
                            <i class="fa-solid fa-location-dot"></i>
                            موقع القسم الرجال  
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="https://maps.app.goo.gl/mnxYorDidK3eU1L77">
                            <i class="fa-solid fa-map-location-dot"></i>
                            موقع القسم النسائي
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        الحوكمة
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <!-- <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-newspaper"></i>
                            اللوائح والأنظمة والسياسات
                          </a>
                        </li> -->
                        <li>
                          <a class="dropdown-item" href="policies.html">
                            <i class="fa-regular fa-newspaper"></i>
                            سياسات الجمعية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="adminregulations.html">
                            <i class="fa-regular fa-newspaper"></i>
                            لوائح وأنظمة الإدارة العامة
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="fieldregulations.html">
                            <i class="fa-regular fa-newspaper"></i>
                            لوائح وأنظمة الميدان
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="associations-leaders.html">
                            <i class="fa-solid fa-users"></i>
                            القائمين على الجمعية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="annual-budget.html">
                            <i class="fa-solid fa-coins"></i>
                            المزانية السنوية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="standing-committees.html">
                            <i class="fa-solid fa-user-group"></i>
                             اللجان الدائمة </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="association-offices.html">
                            <i class="fa-solid fa-briefcase"></i>
                             مكاتب الجمعية </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-credit-card"></i>
                             قرارات التملك </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="annual-reports.html">
                            <i class="fa-regular fa-file-pdf"></i>
                            التقارير السنوية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="statistics.html">
                            <i class="fa-solid fa-chart-simple"></i>
                             الاحصائيات </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        الجمعية العمومية
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-address-card"></i>
                            الترشح للجمعية العمومية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="meet.html">
                            <i class="fa-regular fa-file-pdf"></i>
                            محاضر الإجتماعات
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="member-general.html">
                            <i class="fa-solid fa-users-viewfinder"></i>
                            أعضاء الجمعية العمومية
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        التبرعات
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="https://store.sonan.sa/">
                            <i class="fa-solid fa-cart-shopping"></i>
                            المتجر الإلكتروني
                          </a>
                        </li>
                        <li>
                            <a class="dropdown-item"  href="https://api.whatsapp.com/send?phone=966508092323" >

                            <i class="fa-solid fa-check"></i>
                            الاستقطاع الشهري
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="bank-info.html">
                            <i class="fa-brands fa-cc-visa"></i>
                            الحسابات البنكية
                          </a>
                        </li>
                        <!-- <li>
                          <a class="dropdown-item" href="#"> برنامج ساند </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#"> برنامج مزايا </a>
                        </li> -->
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        المناقصات
                      </a>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        <i class="fa-solid fa-video"></i>
                        المركز الإعلامي
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="news.html">
                            <i class="fa-solid fa-rss"></i>
                            أخبار الجمعية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="https://www.youtube.com/@Jm_snn">
                            <i class="fa-solid fa-video"></i>
                            القناة المرئية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="https://soundcloud.com/andlrozksmej">
                            <i class="fa-solid fa-headphones"></i>
                            القناة الصوتية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="https://www.youtube.com/@Jm_snn/shorts">
                            <i class="fa-solid fa-chalkboard-user"></i>
                            نماذج من الطلاب
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        <i class="fa-regular fa-address-book"></i>
                        التوظيف والتطوع
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-solid fa-briefcase"></i>
                             بوابة التوظيف </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-solid fa-hand-holding-hand"></i>
                             استمارة التطوع </a>
                        </li>
                        <!-- <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-keyboard"></i>
                            استمارة الفرق التطوعية
                          </a>
                        </li> -->
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        <i class="fa-solid fa-graduation-cap"></i>
                        القسم النسائي
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-solid fa-house"></i>
                            رئيسية التعليم النسائي
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-solid fa-rss"></i>
                            أخبار القسم النسائي
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-newspaper"></i>
                            نتائج الاختبارات
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>
          </div>
          <div class="search col-lg-2 ">
            <button type="button" class="btn btn-success">
              <i class="fa-solid fa-cart-shopping"></i>
              <a href="https://store.sonan.sa/">للتبرع</a>
            </button>
          </div>
        </div>
      </section>

      <section class="objective">
        <div class="container">
            <div class="row">
                <div class="head-daw mt-4">
                    <h2> الإيميلات الرسمية للجمعية</h2>
                        <hr class="first">
                        <hr class="second ">
                </div>
                <hr>
                <div class="col-lg-5 img-plan">
                    <img src="./images/email.jpg" alt="">
                </div>
                <div class="col-lg-7  programme-loop" >
                    <div class="row" style="margin-right:50px;">
                            <div class="col-lg-6 vision " >
                                <h5>الإيميل الرئيسي للجمعية:
                                </h5>
                                <p>
                                    <a style="text-decoration: none;" href= "mailto:numosa2023@gmail.com"> numosa2023@gmail.com

                                    </a>
                                </p>
                            </div>
                            <div class=" col-lg-6 vision mb-5">
                                <h5>قسم المشاريع   :
                                </h5>
                                <p>
                                    <a style="text-decoration: none;" href= "mailto:numosa2023@gmail.com"> numosa2023@gmail.com

                                    </a>
                                </p>
                            </div>                            
                            <div class="col-lg-6 vision mb-5">
                                <h5> الاستشارات  :
                                </h5>
                                <p>
                                    <a style="text-decoration: none;" href= "mailto:numosa2023@gmail.com"> numosa2023@gmail.com

                                    </a>
                                </p>
                            </div>
                            <div class="col-lg-6 vision">
                                <h5>  القسم الإداري :
                                </h5>
                                <p>
                                    <a style="text-decoration: none;" href= "mailto:numosa2023@gmail.com"> numosa2023@gmail.com

                                    </a>
                                </p>
                            </div>
                            <div class=" col-lg-6 vision">
                                <h5> الدعم الفني  :
                                </h5>
                                <p>
                                    <a style="text-decoration: none;" href= "mailto:numosa2023@gmail.com"> numosa2023@gmail.com

                                    </a>
                                </p>
                            </div>
                            <div class=" col-lg-6 vision">
                                <h5>  القسم التقني  :
                                </h5>
                                <p>
                                    <a style="text-decoration: none;" href= "mailto:numosa2023@gmail.com"> numosa2023@gmail.com

                                    </a>
                                </p>
                            </div>
                    </div>
                </div>
            </div>
        </div>
      </section>






  <section id="info-footer">
      <div class="container ">
        <div class="row">
          <div class="col">
              <h4>روابط مهمة</h4>
              <hr>
              <div class="list-important">
                <ul>
                  <li><i class="fa-solid fa-store"></i><a href="">متجر جمعية نمو التعليمية</a></li>
                  <li><i class="fa-brands fa-apple"></i><a href="https://apps.apple.com/sa/app/%D8%AD%D9%81%D8%A7%D8%B8-%D8%A7%D9%84%D8%B7%D8%A7%D9%84%D8%A8/id1604822853?l=ar">منصة حفاظ التعليمية أيفون</a></li>
                  <li><i class="fa-brands fa-android"></i><a href="https://play.google.com/store/apps/details?id=com.arabdt.hoffaz">منصة حفاظ التعليمية أندرويد</a></li>
                  <li><i class="fa-solid fa-globe"></i><a href="https://hofaz.net/">منصة حفاظ (التعليم الذاتي)</a></li>
                </ul>
              </div>
          </div>
          <div class="col">
            <h4>من نحن
            </h4>
            <hr>
            <div class="list-important">
             <p>
              جمعية نمو التعليمية، جمعية مرخصة من المركز الوطني برقم (2009)، تُعنى بتحفيظ وتعليم السنة النبوية وتأهيل الموهوبين والموهوبات من الطلاب والطالبات وتخريج جيل ينفع نفسه ومجتمعه ووطنه من خلال برامج تعليمية نوعية تعتني بالحفظ والفهم وتنمية الملكات بخطط متقنة.
             </p>
            </div>
        </div>
        <div class="col">
          <h4>للإتصال والتواصل</h4>
          <hr>
          <div class="list-important">
            <ul>
              <li>
                <i class="fa-solid fa-location-dot"></i>
                <a href="">المملكة العربية السعودية- القصيم- بريدة- حي الصفراء </a>
              </li>
              <li>
                <i class="fa-solid fa-phone-flip"></i>
                <a href="https://api.whatsapp.com/send?phone=966508092323" >+966508092323
                </a>
              </li>
              <li>
                <i class="fa-solid fa-envelope-open-text"></i>
                <a href="#">sunan.association@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
  </section>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col copyright">
            <h5>جميع الحفوق محفظة لجمعية نمو التعليمية 2023 	&copy;</h5>
        </div>
        <div class="social col">
          <ul class="d-flex justify-content-end">
            <li><a href="https://api.whatsapp.com/send?phone=966508092323"><i class="fa-brands fa-whatsapp"></i></a></li>
            <li><a href="https://www.youtube.com/@Jm_snn"><i class="fa-brands fa-youtube"></i></a></li>
            <li><a href="https://instagram.com/sunan.association?igshid=ZDdkNTZiNTM="><i class="fa-brands fa-instagram"></i></a></li>
            <li><a href="https://www.facebook.com/profile.php?id=100085614072991&mibextid=ZbWKwL"><i class="fa-brands fa-facebook"></i></a></li>
            <li><a href="https://twitter.com/jm_snn?t=NzuxgyqxsOoNt1Phaw_VVw&s=09"><i class="fa-brands fa-twitter"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>


  </main>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
    <script type="text/javascript">
      // jQuery counterUp
      $('[data-toggle="counterUp"]').counterUp({
          delay: 15,
          time: 1500
      });
  </script>
    

    <script src="./js/main.js"></script>
  </body>
</html>
