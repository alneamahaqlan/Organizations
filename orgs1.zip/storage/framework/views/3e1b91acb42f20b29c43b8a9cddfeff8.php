<!DOCTYPE html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>نمو</title>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
        <!-- jQuery Library -->

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

        <!-- Counts JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.rtl.min.css"
      integrity="sha384-gXt9imSW0VcJVHezoNQsP+TNrjYXoGcrqBZJpry9zJt8PCQjobwmhMGaDHTASo9N"
      crossorigin="anonymous"
    />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic&family=Poppins:wght@400;500&display=swap"
      rel="stylesheet"
    />
    
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <header>
      <section id="top-sc-em">
        <div class="container-fluid">
          <div class="top-nav d-flex ">
            <div class=" call-us d-flex ">
              <i class="fa-solid fa-phone-flip mhc-menu-icon"></i>
              <a href="https://api.whatsapp.com/send?phone=966508092323" >اتصل بنا
                </a>
            </div>
            <div class=" problem-rep d-flex">
              <i class="fa-regular fa-thumbs-up mhc-menu-icon"></i>
              <a href="https://api.whatsapp.com/send?phone=966508092323"> الاقتراحات والشكاوى </a>
            </div>
          </div>
        </div>
      </section>

      <section id="navbar">
        <div class="mt-2 al-nav container-fluid">
          <div class="logo col-lg-1   ">
            <a class="navbar-brand logo-nav" href="index.html"
              ><img src="./images/logo.png" alt=""
            /></a>
          </div>
          <div class="navbar-con col-lg-9 ">
            <nav class="navbar navbar-expand-lg navbar-light">
              <div class="container-fluid">
                <button
                  class="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div
                  class="collapse navbar-collapse justify-content-evenly"
                  id="navbarSupportedContent"
                >
                  <ul class="navbar-nav mb-2 mb-lg-0">
                    <li class="nav-item">
                      <a class="nav-link active" aria-current="page" 
                      href="index.html"
                        >الرئيسية</a
                      >
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                      نمو
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          
                          <a class="dropdown-item" href="objectif.html">
                            <i class="fa-solid fa-bullseye"></i>
                          أهداف الجمعية
                            
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="begining.html">
                            <i class="fa-solid fa-flag-checkered"></i>
                            النشأة والبداية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#"> 
                            <i class="fa-solid fa-user-tie"></i>
                            المؤسس 
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="board-of-directors.html">
                            <i class="fa-solid fa-users-line"></i>
                            أعضاء مجلس الإدارة
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="administrative-structure.html">
                            <i class="fa-solid fa-users-gear"></i>
                             الهيكل الإداري </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="operational-plans.html">
                            <i class="fa-solid fa-newspaper"></i>
                             خطط جمعية نمو </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="measu-benefi.html">
                            <i class="fa-solid fa-chart-line"></i>
                            قياس رضا المستفيدين
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="feasibility-policy.html">
                            <i class="fa-solid fa-check"></i>
                             سياسة الجودة </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="vision-message.html">
                            <i class="fa-solid fa-eye"></i>
                            الرؤية والرسالة
                          </a>
                        </li>
                        <!-- <li><hr class="dropdown-divider" /></li>
                        <li>
                          <a class="dropdown-item" href="#"
                            >Something else here</a
                          >
                        </li> -->
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        الخدمات
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-file-lines"></i>

                            نظام نمو
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="setup-loop.html">
                            <i class="fa-solid fa-user-plus"></i>
                            طلب إقامة برنامج
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="initiative.html">
                            <i class="fa-solid fa-handshake-angle"></i>
                            المبادرات
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="email.html">
                            <i class="fa-regular fa-envelope"></i>
                            البريد الإلكتروني
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="training.html">
                            <i class="fa-solid fa-gears"></i>
                            نظام إدارة التدريب لمنسوبي الجمعية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="hoffadh.html">
                            <i class="fa-solid fa-mobile-screen-button"></i>
                            منصة نمو التعليمية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="https://maps.app.goo.gl/mnxYorDidK3eU1L77">
                            <i class="fa-solid fa-location-dot"></i>
                            موقع القسم الرجال  
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="https://maps.app.goo.gl/mnxYorDidK3eU1L77">
                            <i class="fa-solid fa-map-location-dot"></i>
                            موقع القسم النسائي
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        الحوكمة
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <!-- <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-newspaper"></i>
                            اللوائح والأنظمة والسياسات
                          </a>
                        </li> -->
                        <li>
                          <a class="dropdown-item" href="policies.html">
                            <i class="fa-regular fa-newspaper"></i>
                            سياسات الجمعية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="adminregulations.html">
                            <i class="fa-regular fa-newspaper"></i>
                            لوائح وأنظمة الإدارة العامة
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="fieldregulations.html">
                            <i class="fa-regular fa-newspaper"></i>
                            لوائح وأنظمة الميدان
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="associations-leaders.html">
                            <i class="fa-solid fa-users"></i>
                            القائمين على الجمعية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="annual-budget.html">
                            <i class="fa-solid fa-coins"></i>
                            المزانية السنوية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="standing-committees.html">
                            <i class="fa-solid fa-user-group"></i>
                             اللجان الدائمة </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="association-offices.html">
                            <i class="fa-solid fa-briefcase"></i>
                             مكاتب الجمعية </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-credit-card"></i>
                             قرارات التملك </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="annual-reports.html">
                            <i class="fa-regular fa-file-pdf"></i>
                            التقارير السنوية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="statistics.html">
                            <i class="fa-solid fa-chart-simple"></i>
                             الاحصائيات </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        الجمعية العمومية
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-address-card"></i>
                            الترشح للجمعية العمومية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="meet.html">
                            <i class="fa-regular fa-file-pdf"></i>
                            محاضر الإجتماعات
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="member-general.html">
                            <i class="fa-solid fa-users-viewfinder"></i>
                            أعضاء الجمعية العمومية
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        التبرعات
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="https://store.sonan.sa/">
                            <i class="fa-solid fa-cart-shopping"></i>
                            المتجر الإلكتروني
                          </a>
                        </li>
                        <li>
                            <a class="dropdown-item"  href="https://api.whatsapp.com/send?phone=966508092323" >

                            <i class="fa-solid fa-check"></i>
                            الاستقطاع الشهري
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="bank-info.html">
                            <i class="fa-brands fa-cc-visa"></i>
                            الحسابات البنكية
                          </a>
                        </li>
                        <!-- <li>
                          <a class="dropdown-item" href="#"> برنامج ساند </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#"> برنامج مزايا </a>
                        </li> -->
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        المناقصات
                      </a>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        <i class="fa-solid fa-video"></i>
                        المركز الإعلامي
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="news.html">
                            <i class="fa-solid fa-rss"></i>
                            أخبار الجمعية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="https://www.youtube.com/@Jm_snn">
                            <i class="fa-solid fa-video"></i>
                            القناة المرئية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="https://soundcloud.com/andlrozksmej">
                            <i class="fa-solid fa-headphones"></i>
                            القناة الصوتية
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="https://www.youtube.com/@Jm_snn/shorts">
                            <i class="fa-solid fa-chalkboard-user"></i>
                            نماذج من الطلاب
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        <i class="fa-regular fa-address-book"></i>
                        التوظيف والتطوع
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-solid fa-briefcase"></i>
                             بوابة التوظيف </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-solid fa-hand-holding-hand"></i>
                             استمارة التطوع </a>
                        </li>
                        <!-- <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-keyboard"></i>
                            استمارة الفرق التطوعية
                          </a>
                        </li> -->
                      </ul>
                    </li>
                    <li class="nav-item dropdown">
                      <a
                        class="nav-link dropdown-toggle"
                        href="#"
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        <i class="fa-solid fa-graduation-cap"></i>
                        القسم النسائي
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-solid fa-house"></i>
                            رئيسية التعليم النسائي
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-solid fa-rss"></i>
                            أخبار القسم النسائي
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-newspaper"></i>
                            نتائج الاختبارات
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>
          </div>
          <div class="search col-lg-2 ">
            <button type="button" class="btn btn-success">
              <i class="fa-solid fa-cart-shopping"></i>
              <a href="https://numo-uqlat.sa/">للتبرع</a>
            </button>
          </div>
        </div>
      </section>

      <section id="slide-tw">
        <div class="slide">
          <div
            id="carouselExampleIndicators"
            class="carousel slide"
            data-bs-ride="carousel"
          >
            <div class="carousel-indicators">
              <button
                type="button"
                data-bs-target="#carouselExampleIndicators"
                data-bs-slide-to="0"
                class="active"
                aria-current="true"
                aria-label="Slide 1"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleIndicators"
                data-bs-slide-to="1"
                aria-label="Slide 2"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleIndicators"
                data-bs-slide-to="2"
                aria-label="Slide 3"
              ></button>
            </div>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="./images/slide/6.jpeg" class="d-block w-100" alt="..." />
              </div>
              <div class="carousel-item">
                <img src="./images/slide/6.jpeg" class="d-block w-100" alt="..." />
              </div>
              <div class="carousel-item">
                <img src="./images/slide/6.jpeg" class="d-block w-100" alt="..." />
              </div>
            </div>
            <button
              class="carousel-control-prev"
              type="button"
              data-bs-target="#carouselExampleIndicators"
              data-bs-slide="prev"
            >
              <span
                class="carousel-control-prev-icon"
                aria-hidden="true"
              ></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button
              class="carousel-control-next"
              type="button"
              data-bs-target="#carouselExampleIndicators"
              data-bs-slide="next"
            >
              <span
                class="carousel-control-next-icon"
                aria-hidden="true"
              ></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
        </div>
      </section>

      <section id="news ">
        <div class="container ">
          <div class="row news-block">
            <div class="col-lg-2  new-news-title">
              <div class="content-radar"></div>
              <i class="fa-solid fa-rss"></i>
            </div>
            <div class="col-lg-10  new-news news-bar">
              <marquee
                direction="right"
                onmouseover="this.stop()"
                scrollamount="4"
                behavior="scroll"
                onmouseover="this.stop()"
                onmouseout="this.start() "
              >
                <a href="#" class="hvr-pop">افتتاح فرع الجمعية في جدة</a
                ><a> <img src="./images/logo.png" alt="" /> </a>
                <a href="#" class="hvr-pop">افتتاح فرع الجمعية في الرياض</a
                ><a> <img src="./images/logo.png" alt="" /> </a>
                <a href="#" class="hvr-pop">افتتاح فرع الجمعية في الدمام</a
                ><a> <img src="./images/logo.png" alt="" /> </a>
                <a href="#" class="hvr-pop">افتتاح فرع الجمعية في عرعر</a
                ><a> <img src="./images/logo.png" alt="" /> </a>
              </marquee>
            </div>
          </div>
        </div>
      </section>
    </header>

    <main>
      <section id="about">
        <div class="container px-4 py-5" id="hanging-icons">
          <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
            <div class="col d-flex align-items-start">
              <div class="icon-square bg-light text-dark flex-shrink-0 me-3">
                <i class="fa-solid fa-question"></i>
              </div>
              <div>
                <h4>جمعية نمو</h4>
                <p>
                  جمعية نمو: جسور العطاء التي تبني المنازل وتُغيث الملهوف وتدعم الأسر المحتاجة، لنجعل الأمل واقعاً ملموساً.
                </p>
              </div>
            </div>
            <div class="col d-flex align-items-start">
              <div class="icon-square bg-light text-dark flex-shrink-0 me-3">
                <i class="fa-regular fa-envelope"></i>
              </div>
              <div>
                <h4>رسالة الجمعية</h4>
                <p>
                  جمعية نمو: "نعمل من أجل حياة كريمة؛ نقدم الدعم والإغاثة لبناء منازل تؤوي الأسر المحتاجة، ونرسم معهم طريق الأمل.
                </p>
              </div>
            </div>
            <div class="col d-flex align-items-start">
              <div class="icon-square bg-light text-dark flex-shrink-0 me-3">
                <i class="fa-solid fa-eye"></i>
              </div>
              <div>
                <h4>رؤية الجمعية</h4>
                <p>
                  رؤيتنا في جمعية "نمو": مجتمعات قوية ومكتفية ذاتيًا، حيث يحظى كل محتاج بفرصة العيش بكرامة وأمان، من خلال بناء المأوى، وتقديم الإغاثة العاجلة، ودعم الأسر المتعففة لتحقيق الاكتفاء الذاتي.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="example">
        <div class="container">
          <div class="row">
            <div class="col-lg-10 title-ex">
              <h2>نماذج من أعمال الجمعية</h2>
              <hr />
            </div>
            <div class="col-lg-2 more-ex-btn">
              <button type="button" class="btn btn-secondary">
                <a href="https://numo-uqlat.sa/">
                  المزيد من النماذج
                  <i class="fa-solid fa-angles-left"></i>
                </a>
              </button>
            </div>
          </div>
          <div class="row vid mt-4">
            <div class="col">
              <video controls>
                <source src="./video/vid1.mp4" type="video/mp4" />
              </video>
            </div>
            <div class="col">
              <video controls>
                <source src="./video/vid1.mp4" type="video/mp4" />
              </video>
            </div>
            <div class="col">
              <video controls>
                <source src="./video/vid1.mp4" type="video/mp4" />
              </video>
            </div>
            <div class="col">
              <video controls>
                <source src="./video/vid1.mp4" type="video/mp4" />
              </video>
            </div>
            <div class="col">
              <video controls>
                <source src="./video/vid1.mp4" type="video/mp4" />
              </video>
            </div>
          </div>
        </div>
      </section>



      <section id="sunan-news">
        <div class="container">
          <div class="row">
            <div class="col-lg-10 title-ex">
              <h2> اخبار الجمعية </h2>
              <hr />
            </div>
            <div class="col-lg-2 more-ex-btn">
              <button type="button" class="btn btn-secondary">
                <a href="news.html">
                  <i class="fa-solid fa-globe"></i>
                  المزيد من الأخبار
                </a>
              </button>
            </div>
          </div>
          <div class="row featurette">
              <div class="col-md-2">
                  <img src="./images/news.png" alt="">
              </div>
              <div class="col-md-10 content-news">
                <div class="row justify-content-center ">
                  <div class="col-lg-5 mb-4 mt-3">
                    <a href="#">  
                      جمعية نمو تنجح في إكمال بناء منزل للأرملة وأسرتها
                    </a>
                    <p> 
                      في إنجاز يعكس قيم العطاء والتكافل، أعلنت جمعية نمو عن اكتمال بناء منزل جديد للأرملة [اذكر اسم الأرملة إذا كان مسموحًا، أو "إحدى الأمهات الأرامل"] وأبنائها، وذلك بفضل الله ثم تبرعات أهل الخير. يأتي هذا المشروع ضمن جهود الجمعية المتواصلة في دعم الأسر المحتاجة وتوفير المأوى الكريم، مؤكدة على رسالتها في بناء جسور الأمل ومد يد العون لمن هم في أمس الحاجة. وقد أعربت العائلة عن سعادتها الغامرة بهذا الإنجاز الذي يمثل بداية حياة جديدة لهم في بيئة آمنة ومستقرة.
                    </p>
                  </div>
                  <div class="col-lg-5 mt-3 mb-5">
                    <a href="#">  
                      جمعية نمو تنجح في إكمال بناء منزل للأرملة وأسرتها
                    </a>
                    <p> 
                      في إنجاز يعكس قيم العطاء والتكافل، أعلنت جمعية نمو عن اكتمال بناء منزل جديد للأرملة [اذكر اسم الأرملة إذا كان مسموحًا، أو "إحدى الأمهات الأرامل"] وأبنائها، وذلك بفضل الله ثم تبرعات أهل الخير. يأتي هذا المشروع ضمن جهود الجمعية المتواصلة في دعم الأسر المحتاجة وتوفير المأوى الكريم، مؤكدة على رسالتها في بناء جسور الأمل ومد يد العون لمن هم في أمس الحاجة. وقد أعربت العائلة عن سعادتها الغامرة بهذا الإنجاز الذي يمثل بداية حياة جديدة لهم في بيئة آمنة ومستقرة.
                    </p>
                  </div>
                  <!-- <div class="col-lg-5">
                    <a href="#">تخريج دفعة من برنامج بلوغ المرام</a>
                    <p>
                      تم بحمد الله ختم 25 طالب كتاب بلوغ المرام
                      تم بحمد الله ختم 25 طالب كتاب بلوغ المرام
                      تم بحمد الله ختم 25 طالب كتاب بلوغ المرام...
                    </p>
                  </div>
                  <div class="col-lg-5">
                    <a href="#">تخريج دفعة من برنامج بلوغ المرام</a>
                    <p> 
                      تم بحمد الله ختم 25 طالب كتاب بلوغ المرام
                      تم بحمد الله ختم 25 طالب كتاب بلوغ المرام
                      تم بحمد الله ختم 25 طالب كتاب بلوغ المرام...
                    </p>
                  </div> -->
                </div>
              </div>

          </div>
        </div>
      </section>

      <section class="sunan-talk ">
        <div class="container mt-5">
          <div class="row"> 
            <div class="header-talk  d-flex justify-content-center ">
                  <img src="./images/logo.png" alt="">
                  <p style="color: white;"> 
              جمعية نمو: أكثر من مجرد اسم، نحن نبض العطاء الذي يحيي الأمل في كل قلب. في "نمو"، نؤمن بأن كل تبرع، مهما كان صغيرًا، يمتلك قوة هائلة على تغيير حياة. من بناء الملاجئ الآمنة للأسر المحتاجة، إلى توفير الإغاثة العاجلة للمتضررين، ودعم الأيتام لضمان مستقبل مشرق لهم، نحن نعمل بلا كلل لنكون جسرًا بين أيادي الخير ومن يحتاجون إليه. انضموا إلينا اليوم، وكونوا جزءًا من قصص النجاح التي نصنعها معًا. عطاؤكم يزرع، ونحن ننمو به.                  </p>
            </div>
            <div class="content-talk">
              <p>

              </p>
            </div>
          </div>
        </div>
      </section>

      

 <!-- Counts Section -->
    <section class="counts-section ">
        <h2 class="mx-auto d-table my-5 "> أرقام الجمعية</h2>
        <div class=" py-5">
            <div class="container">
                <div class="row">
                    <div class="col  text-center">
                      <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 496.794 496.794" xml:space="preserve" width="60px" height="60px" fill="#902421"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <rect x="298.341" y="5.113" style="fill:#902421;" width="130.176" height="38.872"></rect> <rect x="319.169" y="96.751" style="fill:#902421;" width="130.127" height="38.958"></rect> <rect x="316.986" y="50.601" style="fill:#902421;" width="130.159" height="38.872"></rect> <rect x="292.732" y="143.141" style="fill:#902421;" width="130.212" height="38.89"></rect> <path style="fill:#902421;" d="M271.091,133.005h-118.15l5.268-35.906h-58.023L34.442,320.336h160.894l-0.086,176.458h58.279 l-0.231-234.412H134.226l11.131-76.739h125.786v-0.017c0,0,0.152,0,0.238,0v-52.621 C271.263,133.005,271.193,133.005,271.091,133.005z"></path> <path style="fill:#902421;" d="M138.146,84.059c23.201,0,42.017-18.818,42.017-42.034C180.163,18.818,161.344,0,138.146,0 c-23.217,0-42.034,18.818-42.034,42.025C96.112,65.242,114.93,84.061,138.146,84.059z"></path> <polygon style="fill:#902421;" points="192.334,196.937 192.334,237.02 303.231,237.02 303.231,496.794 350.874,496.794 350.874,237.02 462.352,237.02 462.352,196.937 "></polygon> <polygon style="fill:#902421;" points="41.992,356.405 100.356,356.405 100.356,496.794 125.463,496.794 125.463,356.405 184.101,356.405 184.101,335.268 41.992,335.268 "></polygon> </g> </g> </g></svg>
                        <h2 data-toggle="counterUp">759</h2>
                        <h6>عدد المستفيدين </h6>
                    </div>
                    <div class="col  text-center">
                      <svg fill="#902421" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="60px" height="60px" viewBox="-3.2 -3.2 38.35 38.35" xml:space="preserve" transform="matrix(1, 0, 0, 1, 0, 0)" stroke="#902421"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round" stroke="#CCCCCC" stroke-width="0.7029"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M21.009,22.119h-9.782c-1.809,0-3.3,1.502-3.3,3.312v5.1h16.339v-5.1C24.268,23.621,22.816,22.119,21.009,22.119z"></path> <circle cx="16.117" cy="15.565" r="4.696"></circle> <path d="M8.997,9.43c0-0.997-0.803-1.803-1.798-1.803h-5.38C0.824,7.627,0,8.434,0,9.43v2.817h8.997V9.43z"></path> <circle cx="4.509" cy="4.002" r="2.583"></circle> <path d="M30.177,7.627h-5.38c-0.995,0-1.795,0.806-1.795,1.803v2.817h8.948V9.431C31.95,8.434,31.172,7.627,30.177,7.627z"></path> <circle cx="27.486" cy="4.002" r="2.583"></circle> <path d="M12.138,7.822h8.266c0.57,0,1.033-0.45,1.033-1.021c0-0.571-0.463-1.022-1.033-1.022h-8.266 c-0.571,0-1.033,0.451-1.033,1.022C11.105,7.371,11.567,7.822,12.138,7.822z"></path> <path d="M8.838,20.958c0.21,0,0.422-0.062,0.606-0.195c0.462-0.336,0.564-0.981,0.23-1.442l-3.77-5.205 c-0.336-0.464-0.981-0.566-1.443-0.231c-0.463,0.335-0.565,0.981-0.23,1.443L8,20.534C8.203,20.812,8.519,20.958,8.838,20.958z"></path> <path d="M26.945,13.982c-0.48-0.31-1.118-0.168-1.426,0.312l-3.252,5.075c-0.31,0.479-0.168,1.119,0.312,1.429 c0.172,0.108,0.364,0.161,0.558,0.161c0.34,0,0.674-0.166,0.87-0.476l3.251-5.073C27.566,14.931,27.426,14.291,26.945,13.982z"></path> </g> </g> </g></svg>
                        <h2 data-toggle="counterUp">9</h2>
                        <h6>عدد المشاريع</h6>
                    </div>
                    <div class="col  text-center">
                    <svg width="60px" height="60px" version="1.1" id="_x32_" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512 512" xml:space="preserve" fill="" stroke=""><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <style type="text/css"> .st0{fill:#902421;} </style> <g> <path class="st0" d="M116.738,231.551c0,23.245,14.15,43.315,34.513,49.107c15.262,42.368,55.574,70.776,100.582,70.776 s85.32-28.408,100.58-70.776c20.365-5.792,34.515-25.854,34.515-49.107c0-15.691-6.734-30.652-18.061-40.248l1.661-8.921 c0-3.323-0.229-6.568-0.491-9.821l-0.212-2.593l-2.213,1.374c-30.871,19.146-80.885,27.71-116.754,27.71 c-34.85,0-83.895-8.214-114.902-26.568l-2.259-0.59l-0.188,2.554c-0.192,2.632-0.384,5.256-0.357,8.23l1.632,8.649 C123.466,200.923,116.738,215.876,116.738,231.551z"></path> <path class="st0" d="M356.151,381.077c-9.635-5.97-18.734-11.607-26.102-17.43l-0.937-0.738l-0.972,0.691 c-6.887,4.914-31.204,30.17-51.023,51.172l-10.945-21.273l5.697-4.076v-20.854h-40.07v20.854l5.697,4.076l-10.949,21.281 c-19.825-21.009-44.154-46.265-51.034-51.18l-0.973-0.691l-0.937,0.738c-7.368,5.823-16.469,11.46-26.102,17.43 c-30.029,18.61-64.062,39.697-64.062,77.344c0,22.244,52.241,53.579,168.388,53.579c116.146,0,168.388-31.335,168.388-53.579 C420.213,420.774,386.178,399.687,356.151,381.077z"></path> <path class="st0" d="M131.67,131.824c0,18.649,56.118,42.306,119.188,42.306s119.188-23.656,119.188-42.306v-25.706l43.503-17.702 v55.962c-5.068,0.792-8.964,5.186-8.964,10.45c0,4.503,2.966,8.432,7.242,9.852l-8.653,57.111h40.704l-8.651-57.111 c4.27-1.421,7.232-5.35,7.232-9.852c0-5.295-3.919-9.697-9.014-10.466l-0.21-67.197c0.357-0.621,0.357-1.266,0.357-1.607 c0-0.342,0-0.978-0.149-0.978h-0.002c-0.262-2.446-2.011-4.612-4.56-5.652l-11.526-4.72L267.551,3.238 C262.361,1.118,256.59,0,250.858,0s-11.502,1.118-16.69,3.238L72.834,68.936c-2.863,1.172-4.713,3.773-4.713,6.622 c0,2.842,1.848,5.443,4.716,6.63l58.833,23.928V131.824z"></path> </g> </g></svg>                       
                    <h2 data-toggle="counterUp">179</h2>
                        <h6>  عدد المنتسبين </h6>
                    </div>
                    <div class="col  text-center">
                        <svg fill="#902421" width="60px" height="60px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 511.999 511.999" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M484.131,116.893h-3.839c0.3-10.201-4.548-19.767-13.774-25.807c-14.681-9.607-19.44-18.728-20.607-21.462V59.091 c5.677-0.729,11.166-3.242,15.516-7.592c3.393-3.393,3.393-8.895,0-12.287c-3.393-3.393-8.895-3.393-12.287,0 c-3.677,3.677-9.66,3.677-13.338,0c-1.783-1.783-2.764-4.151-2.764-6.67c0-2.519,0.981-4.887,2.764-6.668 c3.393-3.393,3.393-8.895,0-12.289c-3.393-3.392-8.895-3.393-12.289,0c-5.065,5.065-7.854,11.797-7.854,18.958 c0,7.16,2.789,13.893,7.854,18.957c1.541,1.541,3.236,2.826,5.02,3.912v14.213c-1.167,2.735-5.929,11.855-20.623,21.466 c-9.213,6.038-14.058,15.603-13.761,25.803h-3.835c-4.799,0-8.689,3.89-8.689,8.689s3.89,8.689,8.689,8.689h8.643v182.457h-31.361 v-26.558c6.616-16.21,8.19-33.693,4.386-49.492c-4.458-18.518-15.951-34.287-33.236-45.601 c-43.129-28.226-62.023-55.896-69.662-70.583c31.141-0.732,57.036-24.263,60.54-55.33c0.43-3.806-1.683-7.442-5.201-8.955 c-3.517-1.514-7.612-0.546-10.078,2.383c-6.41,7.607-15.769,11.971-25.679,11.971c-18.494,0-33.539-15.05-33.539-33.551 c0-9.917,4.362-19.276,11.966-25.675c2.931-2.466,3.901-6.562,2.388-10.08c-1.514-3.52-5.158-5.627-8.959-5.202 c-31.569,3.573-55.374,30.246-55.374,62.043c0,26.461,16.558,49.115,39.852,58.187c-4.043,8.878-13.616,25.766-34.187,45.363 c-3.474,3.31-3.608,8.811-0.298,12.285c3.31,3.476,8.809,3.608,12.285,0.298c16.796-16.003,27.062-30.536,33.196-41.32 c9.97,17.538,30.901,45.005,73.233,72.709c29.111,19.055,31.499,47.99,23.589,70.549H159.188 c-4.142-11.838-4.962-24.231-2.267-35.42c3.404-14.135,12.346-26.282,25.862-35.129c7.03-4.602,13.788-9.412,20.087-14.299 c3.791-2.942,4.481-8.399,1.54-12.191c-2.943-3.791-8.4-4.48-12.191-1.54c-5.933,4.603-12.309,9.141-18.952,13.489 c-17.286,11.315-28.781,27.084-33.239,45.601c-3.803,15.793-2.234,33.266,4.378,49.467v26.585h-31.361v-182.46h8.654 c4.799,0,8.689-3.89,8.689-8.689s-3.89-8.689-8.689-8.689h-3.838c0.301-10.201-4.548-19.767-13.775-25.806 c-14.68-9.607-19.44-18.728-20.607-21.463V58.625c4.736-1.088,9.239-3.444,12.921-7.126c3.393-3.393,3.393-8.895,0-12.289 c-3.394-3.393-8.895-3.392-12.289,0c-3.677,3.677-9.662,3.678-13.338,0c-3.677-3.677-3.678-9.661,0-13.339 c3.393-3.393,3.393-8.895,0-12.287c-3.393-3.393-8.895-3.393-12.287,0c-10.452,10.452-10.452,27.462,0,37.915 c2.271,2.271,4.861,4.018,7.615,5.301v12.824c-1.167,2.735-5.928,11.855-20.62,21.464c-9.225,6.041-14.074,15.604-13.774,25.806 h-3.838c-4.799,0-8.689,3.89-8.689,8.689s3.89,8.689,8.689,8.689h8.654V503.31c0,4.799,3.89,8.689,8.689,8.689h421.588 c4.799,0,8.689-3.89,8.689-8.689V172.897c0-4.799-3.89-8.689-8.689-8.689c-4.799,0-8.689,3.89-8.689,8.689v321.723h-41.776 v-360.35h41.776v9.662c0,4.799,3.89,8.689,8.689,8.689c4.799,0,8.689-3.89,8.689-8.689v-9.662h8.643 c4.799,0,8.689-3.89,8.689-8.689C492.82,120.783,488.93,116.893,484.131,116.893z M222.524,62.095 c0-14.346,6.711-27.247,17.31-35.532c-1.37,4.636-2.086,9.496-2.086,14.447c0,28.083,22.842,50.929,50.917,50.929 c4.952,0,9.814-0.717,14.455-2.09c-8.281,10.592-21.181,17.301-35.527,17.301C242.74,107.15,222.524,86.938,222.524,62.095z M95.665,494.62H53.9V134.271h41.765V494.62z M100.455,116.893H49.107c-0.251-3.5,0.747-7.899,5.888-11.264 c9.259-6.057,15.547-12.147,19.791-17.392c4.241,5.243,10.525,11.334,19.778,17.39 C99.707,108.993,100.707,113.393,100.455,116.893z M144.404,494.62h-31.361V334.105h31.361V494.62z M350.217,494.62h-38.011 v-33.251c0-4.799-3.89-8.689-8.689-8.689s-8.689,3.89-8.689,8.689v33.251h-75.223v-77.668c0-19.484,15.851-35.335,35.335-35.335 h4.553c19.484,0,35.335,15.851,35.335,35.335v15.454c0,4.799,3.89,8.689,8.689,8.689s8.689-3.89,8.689-8.689v-15.454 c0-29.066-23.647-52.713-52.713-52.713h-4.553c-29.066,0-52.713,23.647-52.713,52.713v77.668h-40.444V297.542h188.435V494.62z M398.956,494.62h-31.361V334.105h31.361V494.62z M462.89,116.893h-51.344c-0.249-3.502,0.75-7.901,5.882-11.264 c9.259-6.057,15.547-12.147,19.791-17.392c4.241,5.243,10.525,11.334,19.78,17.388 C462.143,108.993,463.142,113.393,462.89,116.893z"></path> </g> </g> <g> <g> <path d="M437.222,190.008c-4.799,0-8.689,3.89-8.689,8.689v28.025c0,4.799,3.89,8.689,8.689,8.689s8.689-3.89,8.689-8.689v-28.025 C445.911,193.898,442.021,190.008,437.222,190.008z"></path> </g> </g> <g> <g> <path d="M437.222,294.797c-4.799,0-8.689,3.89-8.689,8.689v28.025c0,4.799,3.89,8.689,8.689,8.689s8.689-3.89,8.689-8.689v-28.025 C445.911,298.687,442.021,294.797,437.222,294.797z"></path> </g> </g> <g> <g> <path d="M74.788,190.008c-4.799,0-8.689,3.89-8.689,8.689v28.025c0,4.799,3.89,8.689,8.689,8.689c4.799,0,8.689-3.89,8.689-8.689 v-28.025C83.477,193.898,79.587,190.008,74.788,190.008z"></path> </g> </g> <g> <g> <path d="M74.788,294.797c-4.799,0-8.689,3.89-8.689,8.689v28.025c0,4.799,3.89,8.689,8.689,8.689c4.799,0,8.689-3.89,8.689-8.689 v-28.025C83.477,298.687,79.587,294.797,74.788,294.797z"></path> </g> </g> </g></svg>
                        <h2 data-toggle="counterUp">7857</h2>
                        <h6>  عدد التبرعات </h6>
                    </div>
                    <div class="col  text-center">
                      <svg version="1.1" id="STATISTICS" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="60px" height="60px" viewBox="0 0 1800 1800" enable-background="new 0 0 1800 1800" xml:space="preserve" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <g> <path fill="#902421" d="M152.728,528.008c-63.267,0-114.738-51.469-114.738-114.733c0-63.265,51.472-114.734,114.738-114.734 c63.262,0,114.729,51.469,114.729,114.734C267.457,476.539,215.99,528.008,152.728,528.008z M152.728,360.752 c-28.962,0-52.526,23.562-52.526,52.522s23.563,52.521,52.526,52.521c28.958,0,52.517-23.562,52.517-52.521 S181.686,360.752,152.728,360.752z"></path> </g> <g> <path fill="#902421" d="M1124.017,703.674c-63.267,0-114.738-51.465-114.738-114.725c0-63.267,51.472-114.738,114.738-114.738 c63.262,0,114.729,51.472,114.729,114.738C1238.745,652.209,1187.278,703.674,1124.017,703.674z M1124.017,536.423 c-28.963,0-52.526,23.563-52.526,52.526c0,28.956,23.563,52.513,52.526,52.513c28.957,0,52.517-23.558,52.517-52.513 C1176.533,559.986,1152.974,536.423,1124.017,536.423z"></path> </g> <g> <path fill="#902421" d="M638.373,391.099c-103.739,0-188.138-84.396-188.138-188.133S534.634,14.833,638.373,14.833 c103.733,0,188.125,84.396,188.125,188.133S742.106,391.099,638.373,391.099z M638.373,77.045 c-69.435,0-125.926,56.488-125.926,125.921c0,69.433,56.491,125.921,125.926,125.921c69.429,0,125.913-56.488,125.913-125.921 C764.286,133.533,707.802,77.045,638.373,77.045z"></path> </g> <g> <path fill="#902421" d="M1609.674,391.099c-103.737,0-188.137-84.396-188.137-188.133s84.399-188.133,188.137-188.133 c103.733,0,188.129,84.396,188.129,188.133S1713.407,391.099,1609.674,391.099z M1609.674,77.045 c-69.437,0-125.925,56.488-125.925,125.921c0,69.433,56.488,125.921,125.925,125.921c69.429,0,125.917-56.488,125.917-125.921 C1735.591,133.533,1679.103,77.045,1609.674,77.045z"></path> </g> <g> <rect x="332.296" y="178.864" transform="matrix(0.4637 0.886 -0.886 0.4637 480.4105 -149.1437)" fill="#902421" width="62.214" height="286.801"></rect> </g> <g> <rect x="721.561" y="398.765" transform="matrix(0.767 0.6417 -0.6417 0.767 488.2679 -484.7798)" fill="#902421" width="380.063" height="62.211"></rect> </g> <g> <polygon fill="#902421" points="1216.137,584.88 1176.993,536.524 1473.117,296.842 1512.26,345.197 "></polygon> </g> </g> <g> <path fill="#902421" d="M223.333,1785.167H82.119c-44.068,0-79.922-36.348-79.922-81.023V761.958 c0-44.678,35.854-81.024,79.922-81.024h141.214c44.068,0,79.921,36.346,79.921,81.024v942.185 C303.254,1748.819,267.401,1785.167,223.333,1785.167z M82.119,743.146c-9.767,0-17.71,8.438-17.71,18.812v942.185 c0,10.371,7.943,18.812,17.71,18.812h141.214c9.766,0,17.709-8.44,17.709-18.812V761.958c0-10.374-7.944-18.812-17.709-18.812 H82.119z"></path> </g> <g> <path fill="#902421" d="M708.974,1785.167H567.755c-44.066,0-79.917-38.839-79.917-86.578V651.512 c0-47.74,35.852-86.579,79.917-86.579h141.218c44.066,0,79.917,38.839,79.917,86.579v1047.077 C788.891,1746.328,753.04,1785.167,708.974,1785.167z M567.755,627.146c-9.597,0-17.706,11.159-17.706,24.367v1047.077 c0,13.209,8.108,24.366,17.706,24.366h141.218c9.597,0,17.705-11.157,17.705-24.366V651.512c0-13.208-8.108-24.367-17.705-24.367 H567.755z"></path> </g> <g> <path fill="#902421" d="M1194.621,1785.167h-141.21c-44.072,0-79.926-31.604-79.926-70.452V972.037 c0-38.848,35.854-70.453,79.926-70.453h141.21c44.072,0,79.926,31.605,79.926,70.453v742.678 C1274.547,1753.563,1238.693,1785.167,1194.621,1785.167z M1053.411,963.796c-11.43,0-17.714,6.188-17.714,8.241v742.678 c0,2.053,6.284,8.24,17.714,8.24h141.21c11.431,0,17.714-6.188,17.714-8.24V972.037c0-2.053-6.283-8.241-17.714-8.241H1053.411z"></path> </g> <g> <path fill="#902421" d="M1680.271,1785.167h-141.219c-44.067,0-79.917-38.839-79.917-86.578V651.512 c0-47.74,35.85-86.579,79.917-86.579h141.219c44.072,0,79.926,38.839,79.926,86.579v1047.077 C1760.196,1746.328,1724.343,1785.167,1680.271,1785.167z M1539.052,627.146c-9.599,0-17.705,11.159-17.705,24.367v1047.077 c0,13.209,8.106,24.366,17.705,24.366h141.219c9.604,0,17.714-11.157,17.714-24.366V651.512c0-13.208-8.11-24.367-17.714-24.367 H1539.052z"></path> </g> </g> </g></svg>
                      <h2 data-toggle="counterUp">1595785</h2>
                      <h6>   اجمالي التبرعات  </h6>
                  </div>
                </div>
            </div>
        </div>
    </section>



    <section class="img-sunan mb-5">
      <div class="container">
        <h2 class="mx-auto d-table my-5 "> صور الجمعية </h2>
        <div class="row">
          <div class="col-lg-5">
            <h5>يتكون مبنى الجمعية من :</h5>
            <div class="row">
            <div class="col-lg-6 apprtm">
              <dl>
                <dt> <i class="fa-solid fa-people-line"></i>  القسم الإداري </dt>
                <dd>مكتب المدير</dd>
                <dd>مكتب المحاسب </dd>
                <dd>مكتب  قسم الموارد المالية </dd>
                <dd>مكتب المدير</dd>
                <dd> مكتب الشؤون التعليمية</dd>
                <dt> قسم العلاقات العامة والإعلام</dt>
                <dd>مكتب مدير القسم</dd>
                <dd>  مكتب المصمم</dd>
                <dd> مكتب مبرمج  </dd>
                <dd>  مكتب المسوق الإلكتروني  </dd>
              </dl>
            </div>
            <div class="col-lg-6 apprtm">
              <dl>
                <dt>
                <i class="fa-solid fa-book"></i>
                قسم  الشؤون التعليمية  
                   </dt>
                <dd>مكتب مدير القسم</dd>
                <dd>   مشرف القسم</dd>
                <dd> سكرتير القسم   </dd>
                <dd>مشرف المعلمين   </dd>
                <dd>مشرف المعلمين   </dd>
                <dd> مشرف الحلق </dd>
                <dt>  قسم العلاقات العامة والإعلام  </dt>
                <dd> قاعة الاجتماعات  </dd>
                <dd> قاعة الضيافة</dd>

                <dd>  مكتب المسوق الإلكتروني  </dd>
              </dl>
            </div>
          </div>
          </div>
          <div class="col-lg-7">
            <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
              </div>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="./images/images/1.jpeg" class="d-block w-100" alt="...">
                  <div class="carousel-caption d-none d-md-block">
                    <h5>مكتب المدير </h5>
                    <p>
                      الجهة المسؤولة عن اتخاذ القرارات الإستراتيجية والإشراف على سير العمليات.
                    </p>
                  </div>
                </div>
                <div class="carousel-item">
                  <img  src="./images/images/2.jpeg" class="d-block w-100" alt="...">
                  <div class="carousel-caption d-none d-md-block">
                    <h5>  محاسب الجمعية </h5>
                    <p>
                      مهمة المحاسب هي تسجيل، تحليل، وتلخيص المعاملات المالية لتقديم معلومات دقيقة تساعد في اتخاذ القرارات الاقتصادية.
                    </p>
                  </div>
                </div>
                <div class="carousel-item">
                  <img  src="./images/images/3.jpeg" class="d-block w-100" alt="...">
                  <div class="carousel-caption d-none d-md-block">
                    <h5> المبنى الداخلي</h5>
                    <p>
                      ساحة الجمعيةو القاعات التعليمية
                    </p>
                  </div>
                </div>
    
                
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>









    <section id="example">
      <div class="container">
        <div class="row">
          <div class="col-lg-10 title-ex">
            <h2> قناة جمعية نمو            </h2>
            <hr />
          </div>
          <div class="col-lg-2 more-ex-btn">
            <button type="button" class="btn btn-secondary">
              <a href="https://www.youtube.com/@Jm_snn/shorts">
                <i class="fa-solid fa-circle-play"></i>
                شاهد أكثر 
              </a>
            </button>
          </div>
        </div>
        <div class="row vid mt-4">
          <div class="col">
            <iframe width="311" height="175" src="https://www.youtube.com/embed/UPuWIliLetU" title="تقرير برامج الدورة الصيفية المكثفة لجمعية نمو التعليمية" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen>
            </iframe>
          </div>
          <div class="col">
            <iframe width="311" height="175" src="https://www.youtube.com/embed/UPuWIliLetU" title="تقرير برامج الدورة الصيفية المكثفة لجمعية نمو التعليمية" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen>
            </iframe>
          </div>
          <div class="col">
            <iframe width="311" height="175" src="https://www.youtube.com/embed/UPuWIliLetU" title="تقرير برامج الدورة الصيفية المكثفة لجمعية نمو التعليمية" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen>
            </iframe>
          </div>
          </div>
        </div>
      </div>
    </section>
    



    <section id="about-us">
    <div class="container">
      <div class="row title-about text-center">
        <h2 class="  my-5 ">  
          اعضاء مجلس الادارة
         </h2>
          <div class="col">
              <div class="card">
                  <div class="face front-face">
                      <img src="./images/sagoub.jpg"
                          alt="" class="profile">
                      <div class="pt-3 text-uppercase name">
                          سمير الحربي.
                      </div>
                      <div class="designation"> رئيس مجلي الادارة</div>
                  </div>
                  <div class="face back-face">
                      <span class="fas fa-quote-left"></span>
                      <div class="testimonial">
                        جمعية تختص بالسنة النبوية ولها برامج نوعية شكرا للقائمين على هذ الصرح المبارك
                      </div>
                      <span class="fas fa-quote-right"></span>
                  </div>
              </div>
          </div>
          <div class="col">
              <div class="card">
                  <div class="face front-face">
                    <img src="./images/sagoub.jpg"
                    alt="" class="profile">
                          <div class="pt-3 text-uppercase name">
                            سمير الحربي.
                        </div>
                        <div class="designation">
                          رئيس مجلس الادارة
                        </div>
                  </div>
                  <div class="face back-face">
                      <span class="fas fa-quote-left"></span>
                      <div class="testimonial">
                        جمعية تختص بالسنة النبوية ولها برامج نوعية شكرا للقائمين على هذ الصرح المبارك

                      </div>
                      <span class="fas fa-quote-right"></span>
                  </div>
              </div>
          </div>
          <div class="col">
              <div class="card">
                  <div class="face front-face">
                    <img src="./images/sagoub.jpg"
                    alt="" class="profile">
                          <div class="pt-3 text-uppercase name">
                            سمير الحربي.
                        </div>
                        <div class="designation">
                          رئيس مجلس الادارة
                        </div>
                  </div>
                  <div class="face back-face">
                      <span class="fas fa-quote-left"></span>
                      <div class="testimonial">
                        جمعية تختص بالسنة النبوية ولها برامج نوعية شكرا للقائمين على هذ الصرح المبارك

                      </div>
                      <span class="fas fa-quote-right"></span>
                  </div>
              </div>
          </div>
          <div class="col">
            <div class="card">
                <div class="face front-face">
                  <img src="./images/sagoub.jpg"
                  alt="" class="profile">
                          <div class="pt-3 text-uppercase name">
                            سمير الحربي.
                        </div>
                        <div class="designation">
                          رئيس مجلس الادارة
                        </div>
                </div>
                <div class="face back-face">
                    <span class="fas fa-quote-left"></span>
                    <div class="testimonial">
                      جمعية تختص بالسنة النبوية ولها برامج نوعية شكرا للقائمين على هذ الصرح المبارك

                    </div>
                    <span class="fas fa-quote-right"></span>
                </div>
            </div>
        </div>
      </div>
  </div>
</section>   
  
    <section id="partner">
<div class="container">
	<div class="row title-partner text-center">
    <h2 class="mx-auto  "> شركاء النجاح  </h2>
		<div class="col-md-12">
			<div class="lc-block">
				<div id="carouselLogos" class="carousel slide pt-5 pb-4" data-bs-ride="carousel">

					<div class="carousel-inner px-5">
						<div class="carousel-item active">
							<div class="row">
								<div class="col-6 col-lg-2 align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
								<div class="col-6 col-lg-2  align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
								<div class="col-6 col-lg-2  align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
								<div class="col-6 col-lg-2  align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
								<div class="col-6 col-lg-2  align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
								<div class="col-6 col-lg-2  align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
							</div>

						</div>
						<div class="carousel-item">
							<div class="row">
								<div class="col-6 col-lg-2 align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
                <div class="col-6 col-lg-2 align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
								<div class="col-6 col-lg-2  align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
								<div class="col-6 col-lg-2  align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
								<div class="col-6 col-lg-2  align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>
								<div class="col-6 col-lg-2  align-self-center">
									<img class="d-block w-100 px-3 mb-3" src="./images/73577.jpg" alt="">
								</div>

							</div>

						</div>

					</div>

					<!--
	<ol class="carousel-indicators list-unstyled position-relative mt-3">
		<li data-bs-target="#carouselLogos" data-bs-slide-to="0" class="active bg-dark carousel-control-prev-icon"></li>
		<li data-bs-target="#carouselLogos" data-bs-slide-to="1" class="bg-dark"></li>
	</ol>
	-->

					<div class="w-100 px-3 text-center mt-4">
						<a class="carousel-control-prev position-relative d-inline me-4" href="#carouselLogos" data-bs-slide="prev">
							<svg width="2em" height="2em" viewBox="0 0 16 16" class="text-dark" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"></path>
							</svg>
							<span class="visually-hidden">Previous</span>
						</a>
						<a class="carousel-control-next position-relative d-inline" href="#carouselLogos" data-bs-slide="next">
							<svg width="2em" height="2em" viewBox="0 0 16 16" class="text-dark" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"></path>
							</svg>
							<span class="visually-hidden">Next</span>
						</a>

					</div>


				</div>
			</div><!-- /lc-block -->
		</div><!-- /col -->
	</div>
</div>
</section>
 




  <section id="gift">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 right-gif">
          <h3>
            وقف نمو بمكة المكرمة
          </h3>
          <hr>
          <p class="mt-4">يتمثل الوقف في فندق استثماري مكون من 22 طابق، يقع في شارع العزيزية العام بجوار المستشفى الأهلي السعودي.
            بادر الآن واجعل رصيدك يزدهر بالأجر والثواب.</p>
            <img src="./images/bankinformation/Screenshot 2025-05-26 073414.jpg"  alt="">
        </div>
        <div class="col-lg-6 left-gif ">
            <div class="row ">
              <div class="col">
                <div class="card shadow-sm">
                  <img src="./images/bankinformation/561182_500.jpeg" style="height:312px;" alt="">
                  <div class="card-body">
                    <button type="button" class="btn btn-success  ">
                      <i class="fa-solid fa-cart-shopping"></i>
                      <a href="https://store.sonan.sa/p/54742 ">للتبرع عن طريق المتجر</a>
                    </button>
                  </div>
                </div>
              </div>
              <div class="col">
                <div class="card shadow-sm">
                  <img src="./images/bankinformation/561188_500.jpeg" alt="">
      
                  <div class="card-body">
                    <button type="button" class="btn btn-success">
                      <i class="fa-solid fa-cart-shopping"></i>
                      <a href="https://store.sonan.sa/p/57057 ">للتبرع عن طريق المتجر</a>
                    </button>
                  </div>
                </div>
              </div>

        </div>
    </div>
  </section>

  <section id="info-footer">
      <div class="container ">
        <div class="row">
          <div class="col">
              <h4>روابط مهمة</h4>
              <hr>
              <div class="list-important">
                <ul>
                  <li><i class="fa-solid fa-store"></i><a href="https://numo-uqlat.sa/">متجر جمعية نمو التعليمية</a></li>
                  <li><i class="fa-solid fa-store"></i><a href="https://numo-uqlat.sa/">متجر جمعية نمو التعليمية</a></li>
                  <li><i class="fa-solid fa-store"></i><a href="https://numo-uqlat.sa/">متجر جمعية نمو التعليمية</a></li>
                  <li><i class="fa-solid fa-store"></i><a href="https://numo-uqlat.sa/">متجر جمعية نمو التعليمية</a></li>
                </ul>
              </div>
          </div>
          <div class="col">
            <h4>من نحن
            </h4>
            <hr>
            <div class="list-important">
             <p>
              جمعية نمو التعليمية، جمعية مرخصة من المركز الوطني برقم (2009)، تُعنى بتحفيظ وتعليم السنة النبوية وتأهيل الموهوبين والموهوبات من الطلاب والطالبات وتخريج جيل ينفع نفسه ومجتمعه ووطنه من خلال برامج تعليمية نوعية تعتني بالحفظ والفهم وتنمية الملكات بخطط متقنة.
             </p>
            </div>
        </div>
        <div class="col">
          <h4>للإتصال والتواصل</h4>
          <hr>
          <div class="list-important">
            <ul>
              <li>
                <i class="fa-solid fa-location-dot"></i>
                <a href="">المملكة العربية السعودية- القصيم- عقلة الصقور- امباري  </a>
              </li>
              <li>
                <i class="fa-solid fa-phone-flip"></i>
                <a href="https://api.whatsapp.com/send?phone=966565675988" >+966565675988
                </a>
              </li>
              <li>
                <i class="fa-solid fa-envelope-open-text"></i>
                <a href="#">numosa2023@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
  </section>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col copyright">
            <h5>جميع الحفوق محفظة لجمعية نمو التعليمية 2025 	&copy;</h5>
        </div>
        <div class="social col">
          <ul class="d-flex justify-content-end">
            <li><a href="https://api.whatsapp.com/send?phone=966565675988"><i class="fa-brands fa-whatsapp"></i></a></li>
            <li><a href="https://www.youtube.com/@Jm_snn"><i class="fa-brands fa-youtube"></i></a></li>
            <li><a href="https://instagram.com/sunan.association?igshid=ZDdkNTZiNTM="><i class="fa-brands fa-instagram"></i></a></li>
            <li><a href="https://www.facebook.com/profile.php?id=100085614072991&mibextid=ZbWKwL"><i class="fa-brands fa-facebook"></i></a></li>
            <li><a href="https://twitter.com/jm_snn?t=NzuxgyqxsOoNt1Phaw_VVw&s=09"><i class="fa-brands fa-twitter"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>


  </main>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
    <script type="text/javascript">
      // jQuery counterUp
      $('[data-toggle="counterUp"]').counterUp({
          delay: 15,
          time: 1500
      });
  </script>
    <script src="./js/main.js"></script>
  </body>
</html>
<?php /**PATH C:\laragon\www\orgs\resources\views/index.blade.php ENDPATH**/ ?>