<section id="about-us">
    <div class="container">
        <div class="row title-about text-center">
            <h2 class="  my-5 ">
                اعضاء مجلس الادارة
            </h2>
            <div class="col">
                <div class="card">
                    <div class="face front-face">
                        <img src="./images/sagoub.jpg" alt="" class="profile">
                        <div class="pt-3 text-uppercase name">
                            سمير الحربي.
                        </div>
                        <div class="designation"> رئيس مجلي الادارة</div>
                    </div>
                    <div class="face back-face">
                        <span class="fas fa-quote-left"></span>
                        <div class="testimonial">
                            جمعية تختص بالسنة النبوية ولها برامج نوعية شكرا للقائمين على هذ الصرح المبارك
                        </div>
                        <span class="fas fa-quote-right"></span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="face front-face">
                        <img src="./images/sagoub.jpg" alt="" class="profile">
                        <div class="pt-3 text-uppercase name">
                            سمير الحربي.
                        </div>
                        <div class="designation">
                            رئيس مجلس الادارة
                        </div>
                    </div>
                    <div class="face back-face">
                        <span class="fas fa-quote-left"></span>
                        <div class="testimonial">
                            جمعية تختص بالسنة النبوية ولها برامج نوعية شكرا للقائمين على هذ الصرح المبارك

                        </div>
                        <span class="fas fa-quote-right"></span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="face front-face">
                        <img src="./images/sagoub.jpg" alt="" class="profile">
                        <div class="pt-3 text-uppercase name">
                            سمير الحربي.
                        </div>
                        <div class="designation">
                            رئيس مجلس الادارة
                        </div>
                    </div>
                    <div class="face back-face">
                        <span class="fas fa-quote-left"></span>
                        <div class="testimonial">
                            جمعية تختص بالسنة النبوية ولها برامج نوعية شكرا للقائمين على هذ الصرح المبارك

                        </div>
                        <span class="fas fa-quote-right"></span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="face front-face">
                        <img src="./images/sagoub.jpg" alt="" class="profile">
                        <div class="pt-3 text-uppercase name">
                            سمير الحربي.
                        </div>
                        <div class="designation">
                            رئيس مجلس الادارة
                        </div>
                    </div>
                    <div class="face back-face">
                        <span class="fas fa-quote-left"></span>
                        <div class="testimonial">
                            جمعية تختص بالسنة النبوية ولها برامج نوعية شكرا للقائمين على هذ الصرح المبارك

                        </div>
                        <span class="fas fa-quote-right"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>