      <section id="example">
          <div class="container">
              <div class="row">
                  <div class="col-lg-10 title-ex">
                      <h2>{{ __('نماذج من أعمال الجمعية') }}</h2>
                      <hr />
                  </div>
                  <div class="col-lg-2 more-ex-btn">
                      <a href="https://numo-uqlat.sa/" class="btn btn-secondary" role="button">
                          {{ __('المزيد من النماذج') }}
                          <i class="fa-solid fa-angles-left"></i>
                      </a>
                  </div>
              </div>
              <div class="row vid mt-4">
                  <div class="col">
                      <video controls>
                          <source src="./video/vid1.mp4" type="video/mp4" />
                      </video>
                  </div>
                  <div class="col">
                      <video controls>
                          <source src="./video/vid1.mp4" type="video/mp4" />
                      </video>
                  </div>
                  <div class="col">
                      <video controls>
                          <source src="./video/vid1.mp4" type="video/mp4" />
                      </video>
                  </div>
                  <div class="col">
                      <video controls>
                          <source src="./video/vid1.mp4" type="video/mp4" />
                      </video>
                  </div>
                  <div class="col">
                      <video controls>
                          <source src="./video/vid1.mp4" type="video/mp4" />
                      </video>
                  </div>
              </div>
          </div>
      </section>