<footer>
    <section id="info-footer">
        <div class="container ">
            <div class="row">
                <div class="col">
                    <h4>روابط مهمة</h4>
                    <hr>
                    <div class="list-important">
                        <ul>
                            <li><i class="fa-solid fa-store"></i><a href="https://numo-uqlat.sa/">متجر جمعية نمو
                                    التعليمية</a></li>
                            <li><i class="fa-solid fa-store"></i><a href="https://numo-uqlat.sa/">متجر جمعية نمو
                                    التعليمية</a></li>
                            <li><i class="fa-solid fa-store"></i><a href="https://numo-uqlat.sa/">متجر جمعية نمو
                                    التعليمية</a></li>
                            <li><i class="fa-solid fa-store"></i><a href="https://numo-uqlat.sa/">متجر جمعية نمو
                                    التعليمية</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col">
                    <h4>من نحن
                    </h4>
                    <hr>
                    <div class="list-important">
                        <p>
                            جمعية نمو التعليمية، جمعية مرخصة من المركز الوطني برقم (2009)، تُعنى بتحفيظ وتعليم السنة
                            النبوية
                            وتأهيل الموهوبين والموهوبات من الطلاب والطالبات وتخريج جيل ينفع نفسه ومجتمعه ووطنه من خلال
                            برامج
                            تعليمية نوعية تعتني بالحفظ والفهم وتنمية الملكات بخطط متقنة.
                        </p>
                    </div>
                </div>
                <div class="col">
                    <h4>للإتصال والتواصل</h4>
                    <hr>
                    <div class="list-important">
                        <ul>
                            <li>
                                <i class="fa-solid fa-location-dot"></i>
                                <a href="">المملكة العربية السعودية- القصيم- عقلة الصقور- امباري </a>
                            </li>
                            <li>
                                <i class="fa-solid fa-phone-flip"></i>
                                <a href="https://api.whatsapp.com/send?phone=966565675988">+966565675988
                                </a>
                            </li>
                            <li>
                                <i class="fa-solid fa-envelope-open-text"></i>
                                <a href="#">numosa2023@gmail.com
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
    </section>
    <div class="container">
        <div class="row">
            <div class="col copyright">
                <h5>جميع الحقوق محفوظة لجمعية نمو التعليمية 2025 &copy;</h5>
            </div>
            <div class="social col">
                <ul class="d-flex justify-content-end">
                    <li><a href="https://api.whatsapp.com/send?phone=966565675988"><i
                                class="fa-brands fa-whatsapp"></i></a></li>
                    <li><a href="https://www.youtube.com/@Jm_snn"><i class="fa-brands fa-youtube"></i></a></li>
                    <li><a href="https://instagram.com/sunan.association"><i class="fa-brands fa-instagram"></i></a>
                    </li>
                    <li><a href="https://facebook.com/profile.php?id=100085614072991"><i
                                class="fa-brands fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/jm_snn"><i class="fa-brands fa-twitter"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>