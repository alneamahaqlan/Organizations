 <section id="news ">
     <div class="container ">
         <div class="row news-block">
             <div class="col-lg-2  new-news-title">
                 <div class="content-radar"></div>
                 <i class="fa-solid fa-rss"></i>
             </div>
             <div class="col-lg-10  new-news news-bar">
                 <marquee direction="right" onmouseover="this.stop()" scrollamount="4" behavior="scroll"
                     onmouseover="this.stop()" onmouseout="this.start() ">
                     <a href="#" class="hvr-pop">افتتاح فرع الجمعية في جدة</a><a> <img src="./images/logo.png" alt="" />
                     </a>
                     <a href="#" class="hvr-pop">افتتاح فرع الجمعية في الرياض</a><a> <img src="./images/logo.png"
                             alt="" /> </a>
                     <a href="#" class="hvr-pop">افتتاح فرع الجمعية في الدمام</a><a> <img src="./images/logo.png"
                             alt="" /> </a>
                     <a href="#" class="hvr-pop">افتتاح فرع الجمعية في عرعر</a><a> <img src="./images/logo.png"
                             alt="" /> </a>
                 </marquee>
             </div>
         </div>
     </div>
 </section>