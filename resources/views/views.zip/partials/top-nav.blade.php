<section id="top-sc-em">
    <div class="container-fluid">
        <div class="top-nav d-flex ">
            <div class=" call-us d-flex ">
                <i class="fa-solid fa-phone-flip mhc-menu-icon"></i>
                <a href="https://api.whatsapp.com/send?phone=966508092323">اتصل بنا
                </a>
            </div>
            <div class=" problem-rep d-flex">
                <i class="fa-regular fa-thumbs-up mhc-menu-icon"></i>
                <a href="https://api.whatsapp.com/send?phone=966508092323"> الاقتراحات والشكاوى </a>
            </div>
        </div>
    </div>
</section>