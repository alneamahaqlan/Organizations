 <section id="example">
     <div class="container">
         <div class="row">
             <div class="col-lg-10 title-ex">
                 <h2> قناة جمعية نمو </h2>
                 <hr />
             </div>
             <div class="col-lg-2 more-ex-btn">
                 <button type="button" class="btn btn-secondary">
                     <a href="https://www.youtube.com/@Jm_snn/shorts">
                         <i class="fa-solid fa-circle-play"></i>
                         شاهد أكثر
                     </a>
                 </button>
             </div>
         </div>
         <div class="row vid mt-4">
             <div class="col">
                 <iframe width="311" height="175" src="https://www.youtube.com/embed/UPuWIliLetU"
                     title="تقرير برامج الدورة الصيفية المكثفة لجمعية نمو التعليمية" frameborder="0"
                     allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                     allowfullscreen>
                 </iframe>
             </div>
             <div class="col">
                 <iframe width="311" height="175" src="https://www.youtube.com/embed/UPuWIliLetU"
                     title="تقرير برامج الدورة الصيفية المكثفة لجمعية نمو التعليمية" frameborder="0"
                     allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                     allowfullscreen>
                 </iframe>
             </div>
             <div class="col">
                 <iframe width="311" height="175" src="https://www.youtube.com/embed/UPuWIliLetU"
                     title="تقرير برامج الدورة الصيفية المكثفة لجمعية نمو التعليمية" frameborder="0"
                     allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                     allowfullscreen>
                 </iframe>
             </div>
         </div>
     </div>
     </div>
 </section>