<section id="gift">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 right-gif">
                <h3>
                    وقف نمو بمكة المكرمة
                </h3>
                <hr>
                <p class="mt-4">يتمثل الوقف في فندق استثماري مكون من 22 طابق، يقع في شارع العزيزية العام بجوار المستشفى
                    الأهلي السعودي.
                    بادر الآن واجعل رصيدك يزدهر بالأجر والثواب.</p>
                <img src="./images/bankinformation/Screenshot 2025-05-26 073414.jpg" alt="">
            </div>
            <div class="col-lg-6 left-gif ">
                <div class="row ">
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="./images/bankinformation/561182_500.jpeg" style="height:312px;" alt="">
                            <div class="card-body">
                                <button type="button" class="btn btn-success  ">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                    <a href="https://store.sonan.sa/p/54742 ">للتبرع عن طريق المتجر</a>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="./images/bankinformation/561188_500.jpeg" alt="">

                            <div class="card-body">
                                <button type="button" class="btn btn-success">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                    <a href="https://store.sonan.sa/p/57057 ">للتبرع عن طريق المتجر</a>
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
</section>