<div class="carousel-inner">
    <div class="carousel-item active">
      <img src="{{ asset("./images/works/8-min.JPG") }}"  class="d-block w-100" alt="..." class="img-fluid">
      <div class="carousel-caption d-none d-md-block">
        <h5>معرض الجمعية</h5>
        <p>يعرض فيه اصدارات الجمعية من كتب وخطط </p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="{{ asset("./images/works/5.JPG") }}"  class="d-block w-100" alt="..." class="img-fluid">
      <div class="carousel-caption d-none d-md-block">
        <h5> مكتبة الجمعية </h5>
        <p>
          اللقاءات العلمية ومكان للطلاب للدراسة
        </p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="{{ asset("./images/works/1.JPG") }}"  class="d-block w-100" alt="..." class="img-fluid">
      <div class="carousel-caption d-none d-md-block">
        <h5> المبنى الداخلي</h5>
        <p>
          ساحة الجمعيةو القاعات التعليمية
        </p>
      </div>
    </div>

    
  </div>